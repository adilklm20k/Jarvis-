# Code of Conduct

Participants are expected to communicate respectfully, provide constructive feedback, protect private information, and avoid harassment or discrimination. Maintainers may remove harmful content or restrict participation where necessary. Report concerns privately to the repository owner.
