# Contributing

## Workflow
1. Read `README.md`, the current roadmap, and feature registry.
2. Inspect the current repository before editing.
3. Work only on the explicitly requested phase and scope.
4. Preserve completed work; prefer small, reviewable changes.
5. Add or update tests and documentation with implementation.
6. Validate files and report exact commands/results.
7. Never claim compilation, testing, or device verification unless performed.

## Branches and commits
Use short descriptive branches, e.g. `phase-01/android-foundation`.
Use conventional commits, e.g. `docs: establish project architecture`.

## Code standards
Use clear names, dependency boundaries, structured errors/logging, and testable interfaces. Avoid fake implementations and unnecessary modules.

## Secrets
Never commit API keys, tokens, passwords, private certificates, or production credentials. Use platform secure storage and local development configuration excluded from Git.

## Pull requests
Describe scope, changed files, validation performed, known limitations, and follow-up work.
