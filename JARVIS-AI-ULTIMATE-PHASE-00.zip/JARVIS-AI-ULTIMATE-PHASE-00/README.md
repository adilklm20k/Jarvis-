# JARVIS AI ULTIMATE

A unified Android + Windows AI assistant ecosystem, developed incrementally through documented phases.

## Current status
**Phase 00 — Foundation and architecture.** This package contains architecture documentation, governance, security design, a feature registry, roadmap, and initial shared task-contract examples. It is not an application build and does not claim that runtime features are implemented.

## Platforms and intended stack
- Android: Kotlin, Jetpack Compose, Room, DataStore, Coroutines/Flow, Hilt, WorkManager, Android Keystore.
- Windows: C#, supported .NET LTS, WPF/MVVM, Windows UI Automation, secure Windows credential storage.
- Shared: versioned JSON contracts and schemas; authenticated device communication is planned, not implemented here.

## Repository map
See `docs/architecture/SYSTEM_ARCHITECTURE.md` and `docs/development/DEVELOPMENT_WORKFLOW.md`.

## Development principles
- Inspect the repository and feature registry before every change.
- Implement one phase at a time; preserve working files.
- Never commit secrets.
- Distinguish PLANNED, DESIGNED, IMPLEMENTED, TESTED, and VERIFIED.
- OS permissions and service-specific restrictions must be respected.

## Current phase
Phase 00 deliverables are provided as documentation and starter JSON contracts. Phase 01 must not begin until Phase 00 has been reviewed and committed.
