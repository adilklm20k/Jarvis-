# Security Policy

## Reporting
Do not publish exploitable vulnerabilities, credentials, or private user data in public issues. Use GitHub's private vulnerability reporting when enabled for this repository; otherwise contact the repository owner through a private channel.

## Security commitments
- No secrets in source control.
- Use Android Keystore and Windows secure credential storage for sensitive local secrets.
- Authenticate and authorize device-to-device communication.
- Encrypt transport; define key rotation and revocation before production pairing.
- Minimize collected data and redact sensitive logs.
- Require explicit confirmation for sensitive or irreversible actions.
- Respect OS security boundaries and third-party service terms.

## Scope and status
This is a project policy, not a security certification. Threat modeling, implementation, penetration testing, and release review remain future work.
