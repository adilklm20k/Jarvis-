# AI Brain Architecture

## Provider abstraction
Plan a common provider interface for Gemini, OpenAI, Claude, DeepSeek, Groq, and local models where supported. Provider-specific request/response formats remain inside adapters.

## Capabilities
Model selection, streaming, tool-call normalization, cancellation, timeout, bounded retry, quota/error classification, and connection testing.

## Orchestration
Separate model output from authorization. AI may propose a tool call; a deterministic policy layer validates schema, permissions, user approval, and allowed scope before execution.

## Secrets
Credentials belong in platform secure storage or a secure backend. Never embed keys in source code, shared contracts, prompts, logs, or repository files.

## Honest status
This document is a design. No provider integration is implemented by this Phase 00 package.
