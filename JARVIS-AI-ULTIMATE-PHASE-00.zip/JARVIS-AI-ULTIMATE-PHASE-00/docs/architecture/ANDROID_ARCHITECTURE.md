# Android Architecture

## Intended stack
Kotlin, Jetpack Compose, Material 3, Coroutines/Flow, Room, DataStore, Hilt, WorkManager, Android Keystore.

## Suggested layers
- `app`: application entry point, navigation, dependency composition.
- `core`: common result/error types, dispatching, time, logging abstractions.
- feature modules: AI, memory, voice, vision, automation, avatar, security.

Create Gradle modules only when there is real code and a stable dependency boundary. Avoid empty placeholder modules.

## Platform rules
Use foreground services only for user-visible work that qualifies under Android rules. AccessibilityService is restricted to legitimate accessibility/UI automation use cases and must be transparent to the user. Overlay, microphone, camera, notification, and background execution require platform-compliant permissions and user controls.

## Persistence
Room for structured local data; DataStore for typed preferences; Android Keystore for cryptographic key protection. Do not store API credentials in ordinary preferences or logs.
