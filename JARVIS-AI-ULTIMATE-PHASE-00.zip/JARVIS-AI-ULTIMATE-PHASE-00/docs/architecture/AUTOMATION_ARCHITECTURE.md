# Automation Architecture

## Shared lifecycle
Observe → Understand → Plan → Validate → Approve when required → Act → Verify → Recover → Report.

## Components
- Task orchestrator and state machine.
- Capability registry.
- Platform adapters.
- App/service-specific adapters only where required.
- Policy and approval gate.
- Evidence-based verifier.
- Checkpoint and recovery manager.
- Audit/event log.

## Execution controls
Each task should have an ID, bounded timeout, cancellation path, retry policy, checkpoint strategy, and idempotency handling where possible. Retries must not duplicate irreversible actions.

## Limitations
UI automation is inherently app- and OS-dependent. Login, MFA, CAPTCHA, secure screens, permission prompts, protected content, and service policies may require user action or make a task unavailable.
