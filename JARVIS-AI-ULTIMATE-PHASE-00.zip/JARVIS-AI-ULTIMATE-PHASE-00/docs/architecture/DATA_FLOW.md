# Data Flow

## User request
The client captures a request and associates it with a session and source device.

## Context and planning
The orchestrator retrieves only permitted context, identifies required tools, creates a bounded plan, and evaluates permissions and risk.

## Execution
A policy layer validates tool arguments and approval requirements. The platform adapter executes the action and emits structured progress.

## Verification and reporting
The orchestrator checks observable results. If verification fails, it may attempt a bounded safe recovery or ask the user for help. It must not report success based only on an attempted action.

## Data minimization
Store only data needed for the feature. Memory writes must follow user preferences and approval policy. Sensitive values must be excluded from ordinary logs and memory.
