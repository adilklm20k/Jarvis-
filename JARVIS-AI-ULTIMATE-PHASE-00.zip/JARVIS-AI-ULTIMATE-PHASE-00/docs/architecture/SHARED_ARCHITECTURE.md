# Shared Architecture

Shared code is limited to platform-neutral contracts and specifications unless a genuinely portable library is justified.

## Shared assets
- Versioned JSON task and event schemas.
- Common task states and error categories.
- Protocol compatibility policy.
- Example payloads and contract tests.

## Not shared
Android UI, Windows UI, Android services, Windows UI Automation, platform credential stores, and platform-specific lifecycle code.

## Compatibility
Additive optional fields are preferred. Breaking changes require a new schema/protocol version and a documented migration strategy. Consumers must reject invalid payloads safely.
