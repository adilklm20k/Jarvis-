# System Architecture

## Vision
JARVIS is one assistant ecosystem with Android and Windows clients. Platform-specific capabilities are implemented natively; shared contracts keep task semantics and synchronization consistent.

## Logical layers
1. Experience: Compose Android UI and WPF Windows UI.
2. Orchestration: intent handling, planning, approvals, task lifecycle.
3. Domain: conversations, memory, tasks, automation policies.
4. Provider/tool adapters: AI providers, OS capabilities, browser and service integrations.
5. Infrastructure: persistence, secure storage, networking, telemetry.

## Core request lifecycle
Receive request → classify intent → retrieve permitted context → create plan → validate policy and permissions → request approval when required → execute tools → verify observable outcome → recover or report → update memory only under user-controlled policy.

## Boundaries
- Android and Windows do not share platform-specific UI or OS automation code.
- Shared JSON contracts define interoperable task/event data.
- Network transport, identity, encryption, and sync are future implementation work.
- AI output is untrusted input; validate tool arguments and authorize actions independently.

## Reliability
Use task IDs, explicit states, idempotency keys where applicable, bounded retries, timeouts, cancellation, checkpoints, and structured outcomes. Verification must be based on observable evidence, not merely a successful tool invocation.
