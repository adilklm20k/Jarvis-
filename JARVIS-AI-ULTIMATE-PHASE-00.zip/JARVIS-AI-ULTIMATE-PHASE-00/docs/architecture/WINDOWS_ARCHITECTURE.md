# Windows Architecture

## Intended stack
C#, a supported .NET LTS release, WPF with MVVM, Microsoft.Extensions.DependencyInjection and Logging, Windows UI Automation, and SQLite or another justified local persistence layer.

## Suggested projects
- `Jarvis.Desktop`: user interface and application composition.
- `Jarvis.Agent`: background/task agent only if its lifecycle and installation model are justified.
- `Jarvis.AI`: provider and orchestration abstractions.
- `Jarvis.Memory`: memory and persistence.
- `Jarvis.Automation`: UI Automation and workflow engine.
- `Jarvis.Voice`: speech adapters.
- `Jarvis.Security`: secure storage and policy.
- `Jarvis.Tests`: automated tests.

Create projects when implementation begins; do not add empty projects merely to imitate this list.

## Security boundaries
Respect UAC, secure desktop, protected processes, application permissions, sign-in and MFA flows. Windows UI Automation cannot guarantee access to every application or control.
