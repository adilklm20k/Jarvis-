# Automation Safety Model

## Risk tiers
- Low: reversible, local, non-sensitive actions.
- Medium: actions affecting files, settings, or external services.
- High: financial, identity, privacy, destructive, public-posting, or irreversible actions.

## Controls
Validate target, scope, arguments, permissions, and expected side effects. Require explicit user approval for high-risk actions and for any action whose authorization is unclear.

## Evidence
Record what was observed before and after execution. Verification must check the actual resulting state.

## Recovery
Use bounded alternatives only when safe. Do not repeat a non-idempotent action without checking whether it already succeeded.

## User assistance
When blocked by permissions, sign-in, MFA, CAPTCHA, UAC, or secure screens, explain the exact step needed and resume only after user action and a fresh observation.
