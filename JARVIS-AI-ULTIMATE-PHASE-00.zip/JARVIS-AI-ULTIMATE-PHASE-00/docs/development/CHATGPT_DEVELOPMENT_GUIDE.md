# ChatGPT Development Guide

For every new phase, ChatGPT must:
1. Inspect the current repository structure, relevant source files, recent changes, roadmap, and feature registry.
2. Confirm prerequisites and identify blockers before editing.
3. State the exact scope and files to create/update.
4. Preserve existing working functionality; do not rewrite unrelated files.
5. Provide complete file contents with exact repository paths when direct repository editing is unavailable.
6. Split large work into numbered batches without omitting files.
7. Use compatible, documented dependencies and avoid secrets.
8. Add meaningful tests and update documentation.
9. Validate syntax/configuration where possible.
10. Report what was actually created, compiled, tested, and verified, with evidence.
11. Give GitHub Website steps suitable for Android and meaningful commit messages.
12. Stop at the requested phase; do not silently begin the next phase.

Never claim repository access, commits, builds, tests, or device verification that did not occur.
