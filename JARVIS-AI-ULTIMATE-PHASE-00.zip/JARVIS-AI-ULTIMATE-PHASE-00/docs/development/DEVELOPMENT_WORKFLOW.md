# Development Workflow

## Phase discipline
1. Read the roadmap and feature registry.
2. Inspect the actual repository and recent commits.
3. Confirm prerequisites and current status.
4. Implement only the requested phase.
5. Preserve existing working files and architecture.
6. Add tests and update docs.
7. Run available validation.
8. Report exact evidence and blockers.
9. Commit small, reviewable changes.

## Status vocabulary
PLANNED, DESIGNED, IN_PROGRESS, IMPLEMENTED, COMPILED, TESTED, VERIFIED, BLOCKED. These are not interchangeable.

## GitHub Website
Create the repository, use Add file → Create new file, enter the exact path and contents, preview, commit to the intended branch, and inspect the commit diff. GitHub's browser editor does not itself compile Android or Windows code.

## ChatGPT collaboration
Provide exact paths and complete file contents. Ask ChatGPT to inspect current files before proposing edits. For large changes, split into numbered batches and wait for confirmation between batches.
