# GitHub Website Workflow on Android

1. Open GitHub in the mobile browser and sign in.
2. Create a new repository named `JARVIS-AI-ULTIMATE`.
3. Choose visibility deliberately; private is preferable while the project is early.
4. Add `README.md` first.
5. For each file, use **Add file → Create new file** and type the full path, e.g. `docs/architecture/SYSTEM_ARCHITECTURE.md`.
6. Paste the complete file content, preview it, and commit with a descriptive message.
7. Repeat in small batches; verify each commit in the repository file list.
8. Use branches for larger implementation phases and review diffs before merging.
9. Never paste secrets into GitHub.
10. GitHub Actions can run checks once workflows are added; a green documentation check does not mean the Android app or Windows application compiles.

Mobile UI labels may vary slightly by browser and GitHub updates.
