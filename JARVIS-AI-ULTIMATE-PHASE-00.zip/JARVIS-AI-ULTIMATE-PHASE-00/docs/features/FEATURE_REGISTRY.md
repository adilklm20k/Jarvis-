# Feature Registry

Statuses: PLANNED, DESIGNED, IN_PROGRESS, IMPLEMENTED, COMPILED, TESTED, VERIFIED, BLOCKED.

| ID | Feature | Platform | Dependencies | Acceptance criteria | Status |
|---|---|---|---|---|---|
| F00-01 | System architecture | Shared | None | Architecture and boundaries documented | DESIGNED |
| F00-02 | Shared task protocol | Shared | None | Versioned schemas and valid examples exist | DESIGNED |
| F00-03 | Security/threat model | Shared | None | Assets, threats, mitigations documented | DESIGNED |
| F01-01 | Android project foundation | Android | Phase 00 | App builds and baseline tests pass | PLANNED |
| F01-02 | Windows solution foundation | Windows | Phase 00 | Solution builds and baseline tests pass | PLANNED |
| F02-01 | Database and memory | Both | Phase 01 | Persistence/repositories/tests implemented | PLANNED |
| F03-01 | Multi-provider AI | Both | Phase 02 | Provider adapters and error tests work | PLANNED |
| F04-01 | Reasoning orchestration | Both | Phase 03 | Plans validated and tool policy enforced | PLANNED |
| F05-01 | Advanced chat | Both | Phase 03 | Chat lifecycle and history work | PLANNED |
| F06-01 | Voice assistant | Both | Phase 01, 03 | Speech flows and controls tested | PLANNED |
| F07-01 | 3D avatar | Both | Phase 01, 06 | Offline assets and performance validated | PLANNED |
| F08-01 | Android device control | Android | Phase 01 | Permitted controls verified on device | PLANNED |
| F09-01 | Universal automation | Android | Phase 04, 08 | Observe-act-verify-recover tested | PLANNED |
| F10-01 | Windows companion | Windows | Phase 01 | Desktop shell and agent lifecycle tested | PLANNED |
| F11-01 | Windows automation | Windows | Phase 10 | UI Automation workflows verified | PLANNED |
| F12-01 | Cross-device intelligence | Both | Phase 09, 11 | Authenticated task sync tested | PLANNED |
| F13-01 | Browser automation | Both | Phase 04 | Safe browser workflows verified | PLANNED |
| F14-01 | Vision and camera | Both | Phase 01 | Permission-aware OCR/vision tested | PLANNED |
| F15-01 | App integrations | Both | Phase 03 | Each integration independently tested | PLANNED |
| F16-01 | Personal companion | Both | Phase 02, 05 | User-controlled personalization works | PLANNED |
| F17-01 | Security/privacy implementation | Both | Phase 01 onward | Threat controls tested | PLANNED |
| F18-01 | Autonomous workflows | Both | Phase 09, 11, 12 | Checkpoint/recovery/approval tested | PLANNED |
| F19-01 | Final integration/release | Both | All prior phases | Release criteria and device tests pass | PLANNED |

A status must be updated only with evidence. This registry records design status for Phase 00 artifacts; it does not assert application features are implemented.
