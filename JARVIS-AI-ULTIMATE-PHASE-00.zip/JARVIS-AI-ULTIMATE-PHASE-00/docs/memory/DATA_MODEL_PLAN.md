# Data Model Plan

| Entity | Purpose | Key relationships | Privacy / deletion |
|---|---|---|---|
| Conversation | Chat thread | Has many Messages | User content; cascade or archive per policy |
| Message | Chat item | Belongs to Conversation | User content; delete with conversation unless retained by explicit policy |
| Memory | Durable fact/preference | Category, source, relations | User-controlled review/edit/delete |
| MemoryCategory | Classification | Has many Memories | Low sensitivity metadata |
| MemoryRelation | Links memories | Memory-to-memory | Remove links when either endpoint is deleted |
| UserPreference | Assistant settings | User/device scope | User-controlled export/delete |
| ProjectMemory | Project context | Project and Memory | Scoped retention |
| TaskMemory | Task context | Task and Memory | Expire or delete with task policy |
| Knowledge | Indexed reference | Source and optional chunks | Respect source rights and deletion |
| MemoryEmbedding | Semantic vector | Belongs to Memory/Knowledge | Delete when source is deleted; do not claim vector search until implemented |
| Task | Requested work | Device, executions, events | Audit and retention policy |
| TaskExecution | One execution attempt | Belongs to Task | Keep minimal diagnostics; redact secrets |
| AutomationRule | User-defined trigger/action | References capabilities | Explicit enable/disable and delete |
| Device | Registered endpoint | Pairing and sync metadata | Revocation and unpairing |
| DevicePairing | Trust relationship | Two devices | Revoke and delete securely |
| SyncMetadata | Version/sync state | Entity and device | Tombstones for propagated deletion |
| AuditLog | Security/action history | Actor, task, event | Restricted access and retention |
| BackupMetadata | Backup inventory | Backup artifact | Protected metadata; encrypted backup content |

Implementation phases must define exact fields, indexes, migrations, conflict handling, and retention rules before schema creation.
