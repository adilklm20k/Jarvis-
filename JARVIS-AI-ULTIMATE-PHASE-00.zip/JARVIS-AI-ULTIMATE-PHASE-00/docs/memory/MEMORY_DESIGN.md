# Memory Design

## Memory classes
- Short-term: bounded session context with expiry.
- Conversation: user-visible conversation and message history.
- Long-term: user-approved durable facts/preferences with provenance.
- Project/task: scoped context for ongoing work.
- Knowledge: indexed user-provided or permitted reference material.
- Semantic index: optional embeddings generated and searched by a real implementation.

## Record metadata
Plan for stable ID, category, content, source/provenance, confidence, importance, created/updated timestamps, expiry, approval state, privacy class, and sync metadata.

## Safety
Do not store passwords, API keys, tokens, or security answers. Treat uncertain inference as uncertain, not verified fact. Resolve conflicting facts by preserving provenance and asking the user when needed.

## Retrieval
Combine exact/keyword search, category, recency, importance, and semantic similarity only when embeddings and similarity search are actually implemented.

## User control
Provide review, edit, delete, export, retention, and backup/restore controls. Cross-device sync must handle deletion tombstones and conflicts.
