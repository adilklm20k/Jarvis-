# Security Model

## Assets
User conversations, memory, API credentials, device identity, task data, local databases, backups, and connected-service tokens.

## Principles
Least privilege, data minimization, explicit consent, secure defaults, defense in depth, auditable actions, and safe failure.

## Storage
Android secrets: Android Keystore-backed design. Windows secrets: Windows secure credential storage. Database encryption requirements must be evaluated and implemented before storing sensitive data.

## Communication
Device communication must use authenticated encryption, pairing, authorization scopes, replay protection, and revocation. Do not invent a custom cryptographic protocol.

## Automation
Validate tool arguments independently of model output. Require confirmation for sensitive or irreversible operations. Never bypass OS security.

## Logging
Use structured logs with redaction. Never log passwords, API keys, access tokens, private message contents by default, or full sensitive file paths.

## Lifecycle
Support review, export, deletion, backup protection, credential rotation, and device unpairing.

## Verification
This is a design baseline, not proof of security. Implementation review and security testing are required.
