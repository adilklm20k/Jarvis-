# Threat Model

| Asset / surface | Threat | Planned mitigation | Residual risk |
|---|---|---|---|
| API credentials | Source leak or log exposure | Secure platform storage, redaction, secret scanning | Device compromise |
| Device pairing | Unauthorized device joins | Explicit pairing, strong device identity, revocation | Social engineering |
| Network channel | Interception or replay | Authenticated TLS, nonces/sequence controls | Endpoint compromise |
| AI tool calls | Prompt injection or malformed arguments | Treat model output as untrusted; schema and policy validation | Novel prompt attacks |
| Automation | Accidental destructive action | Risk tiers, confirmation, scope limits, verification | User-approved harmful action |
| Memory | Over-collection or incorrect facts | User controls, provenance, review, deletion | Incorrect user-approved data |
| Backups | Theft or disclosure | Encryption, access control, restore preview | Lost recovery key |
| Dependencies | Supply-chain compromise | Pin versions, review updates, scanning | Upstream compromise |
| Desktop UI automation | Privilege boundary bypass attempt | Respect UAC and secure desktop | OS/application-specific behavior |

Review this model whenever a new integration, permission, or remote execution capability is added.
