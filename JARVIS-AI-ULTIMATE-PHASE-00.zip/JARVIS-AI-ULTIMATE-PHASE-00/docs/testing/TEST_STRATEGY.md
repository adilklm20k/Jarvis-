# Test Strategy

## Android
Unit tests, Room database tests, repository tests, ViewModel tests, Compose UI tests, and instrumentation/integration tests.

## Windows
Unit tests, service tests, automation adapter tests, UI tests where appropriate, and integration tests.

## Shared contracts
Validate JSON against JSON Schema; test serialization, required fields, enum compatibility, unknown optional fields, and protocol version handling.

## System tests
Pairing/authentication, offline/reconnect, duplicate delivery, cancellation, retry, checkpoint recovery, permission boundaries, privacy, and performance.

## Evidence rules
Record command, environment, result, and date. Distinguish source review from execution. A GitHub commit is not a build; a build is not a device test; a unit test is not end-to-end verification.
