# Shared Task Protocol Overview

The initial protocol is a versioned JSON contract, not a network transport implementation. `task.schema.json` defines the task envelope; `task-event.schema.json` defines lifecycle events.

## Task states
CREATED, QUEUED, PLANNING, WAITING_FOR_APPROVAL, READY, RUNNING, VERIFYING, RECOVERING, COMPLETED, FAILED, CANCELLED, PAUSED.

## Error categories
VALIDATION_ERROR, PERMISSION_DENIED, AUTHENTICATION_ERROR, NETWORK_ERROR, PROVIDER_ERROR, TOOL_UNAVAILABLE, TARGET_NOT_FOUND, EXECUTION_ERROR, VERIFICATION_FAILED, TIMEOUT, CANCELLED, UNKNOWN_ERROR.

## Compatibility
Consumers validate schema version and reject malformed payloads. Additive optional fields are preferred; breaking changes require a versioned migration.
